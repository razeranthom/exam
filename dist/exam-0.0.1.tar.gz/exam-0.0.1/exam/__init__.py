"""Top-level package for EXAM."""
# exam/__init__.py

__app_name__ = "exam"
__version__ = "0.0.1"