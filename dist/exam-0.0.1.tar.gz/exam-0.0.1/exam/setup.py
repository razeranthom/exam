from setuptools import setup

setup(
    # Whatever arguments you need/want
)