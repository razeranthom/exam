import sys
from .exam import main

sys.exit(main())