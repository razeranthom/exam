#!/bin/bash

msgfmt -o locales/en/LC_MESSAGES/base.mo locales/en/LC_MESSAGES/base
msgfmt -o locales/pt_BR/LC_MESSAGES/base.mo locales/pt_BR/LC_MESSAGES/base
msgfmt -o locales/es/LC_MESSAGES/base.mo locales/es/LC_MESSAGES/base
